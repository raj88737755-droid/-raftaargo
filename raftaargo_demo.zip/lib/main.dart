
import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const RaftaarGoApp());
}

class RaftaarGoApp extends StatelessWidget {
  const RaftaarGoApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RaftaarGo Demo',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.blue,
      ),
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}
