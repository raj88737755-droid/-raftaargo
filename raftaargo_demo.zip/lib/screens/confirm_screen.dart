
import 'package:flutter/material.dart';

class ConfirmScreen extends StatelessWidget {
  final String pickup;
  final String drop;
  final String vehicle;
  final double fare;

  const ConfirmScreen({Key? key, required this.pickup, required this.drop, required this.vehicle, required this.fare}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Booking Confirmed')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.check_circle, size: 72),
            const SizedBox(height: 12),
            const Text('Your delivery is booked!', textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            Text('Pickup: $pickup'),
            Text('Drop: $drop'),
            Text('Vehicle: $vehicle'),
            Text('Fare: ₹${fare.toStringAsFixed(2)}'),
            const Spacer(),
            ElevatedButton(
              onPressed: () => Navigator.popUntil(context, (route) => route.isFirst),
              child: const Text('Back to Home'),
            ),
          ],
        ),
      ),
    );
  }
}
