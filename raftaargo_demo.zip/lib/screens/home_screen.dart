
import 'package:flutter/material.dart';
import 'login_screen.dart';
import 'driver/login_driver_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool customerMode = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('RaftaarGo Demo'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text('Driver'),
                Switch(
                  value: customerMode,
                  onChanged: (v) => setState(() => customerMode = v),
                ),
                const Text('Customer'),
              ],
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () {
                if (customerMode) {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
                } else {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginDriverScreen()));
                }
              },
              icon: const Icon(Icons.arrow_forward),
              label: Text(customerMode ? 'Enter Customer Flow' : 'Enter Driver Flow'),
            ),
            const Spacer(),
            const Text(
              'Note: This is a mocked prototype to preview UX quickly. No real OTP/Maps/Payments yet.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
