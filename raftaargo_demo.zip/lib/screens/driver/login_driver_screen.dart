
import 'package:flutter/material.dart';
import 'incoming_job_screen.dart';

class LoginDriverScreen extends StatefulWidget {
  const LoginDriverScreen({Key? key}) : super(key: key);

  @override
  State<LoginDriverScreen> createState() => _LoginDriverScreenState();
}

class _LoginDriverScreenState extends State<LoginDriverScreen> {
  final TextEditingController phone = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Login (Driver)')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: phone,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'Phone number', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const IncomingJobScreen()));
              },
              child: const Text('Go Online (Mock)'),
            )
          ],
        ),
      ),
    );
  }
}
