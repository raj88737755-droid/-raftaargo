
import 'package:flutter/material.dart';

class IncomingJobScreen extends StatefulWidget {
  const IncomingJobScreen({Key? key}) : super(key: key);

  @override
  State<IncomingJobScreen> createState() => _IncomingJobScreenState();
}

class _IncomingJobScreenState extends State<IncomingJobScreen> {
  bool accepted = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Incoming Job')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Job Request', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Pickup: Badarpur, Delhi'),
            const Text('Drop: Saket, Delhi'),
            const Text('Vehicle: Bike'),
            const Text('Payout: ₹72'),
            const SizedBox(height: 24),
            if (!accepted) ...[
              ElevatedButton(onPressed: () => setState(() => accepted = true), child: const Text('Accept')),
              TextButton(onPressed: () => Navigator.pop(context), child: const Text('Reject')),
            ] else ...[
              const Icon(Icons.check_circle, size: 64),
              const SizedBox(height: 12),
              const Text('Accepted! Navigate to pickup (mocked).', textAlign: TextAlign.center),
              const SizedBox(height: 24),
              ElevatedButton(onPressed: () => Navigator.popUntil(context, (route) => route.isFirst), child: const Text('Finish')),
            ]
          ],
        ),
      ),
    );
  }
}
