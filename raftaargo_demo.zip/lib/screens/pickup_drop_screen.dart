
import 'package:flutter/material.dart';
import 'vehicle_screen.dart';

class PickupDropScreen extends StatefulWidget {
  const PickupDropScreen({Key? key}) : super(key: key);

  @override
  State<PickupDropScreen> createState() => _PickupDropScreenState();
}

class _PickupDropScreenState extends State<PickupDropScreen> {
  final TextEditingController pickup = TextEditingController(text: 'Badarpur, Delhi');
  final TextEditingController drop = TextEditingController(text: 'Saket, Delhi');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pickup & Drop')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: pickup,
              decoration: const InputDecoration(labelText: 'Pickup location', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: drop,
              decoration: const InputDecoration(labelText: 'Drop location', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            Container(
              height: 180,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey.shade300),
              ),
              child: const Text('Map preview (mocked)'),
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => VehicleScreen(pickup: pickup.text, drop: drop.text)));
              },
              child: const Text('Choose Vehicle'),
            )
          ],
        ),
      ),
    );
  }
}
