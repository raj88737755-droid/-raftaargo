
import 'package:flutter/material.dart';
import 'confirm_screen.dart';

class FareScreen extends StatelessWidget {
  final String pickup;
  final String drop;
  final String vehicle;

  const FareScreen({Key? key, required this.pickup, required this.drop, required this.vehicle}) : super(key: key);

  double _estimate() {
    // Simple mocked fare
    final base = vehicle == 'Bike' ? 49 : (vehicle == 'Tata Ace' ? 199 : 299);
    return base + 12.5;
  }

  @override
  Widget build(BuildContext context) {
    final fare = _estimate();
    return Scaffold(
      appBar: AppBar(title: const Text('Fare Estimate')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Pickup: $pickup'),
            Text('Drop: $drop'),
            Text('Vehicle: $vehicle'),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey.shade300),
              ),
              child: Text('Estimated Fare: ₹${fare.toStringAsFixed(2)}'),
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => ConfirmScreen(
                  pickup: pickup, drop: drop, vehicle: vehicle, fare: fare,
                )));
              },
              child: const Text('Confirm Booking'),
            ),
          ],
        ),
      ),
    );
  }
}
