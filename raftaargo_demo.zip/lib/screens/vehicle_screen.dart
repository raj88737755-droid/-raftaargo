
import 'package:flutter/material.dart';
import 'fare_screen.dart';

class VehicleScreen extends StatefulWidget {
  final String pickup;
  final String drop;

  const VehicleScreen({Key? key, required this.pickup, required this.drop}) : super(key: key);

  @override
  State<VehicleScreen> createState() => _VehicleScreenState();
}

class _VehicleScreenState extends State<VehicleScreen> {
  String selected = 'Bike';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Select Vehicle')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            RadioListTile(
              title: const Text('Bike (parcel < 15kg)'),
              value: 'Bike',
              groupValue: selected,
              onChanged: (v) => setState(() => selected = v.toString()),
            ),
            RadioListTile(
              title: const Text('Tata Ace / Chhota Hathi'),
              value: 'Tata Ace',
              groupValue: selected,
              onChanged: (v) => setState(() => selected = v.toString()),
            ),
            RadioListTile(
              title: const Text('Pickup Truck'),
              value: 'Pickup Truck',
              groupValue: selected,
              onChanged: (v) => setState(() => selected = v.toString()),
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => FareScreen(
                  pickup: widget.pickup, drop: widget.drop, vehicle: selected,
                )));
              },
              child: const Text('Get Fare'),
            ),
          ],
        ),
      ),
    );
  }
}
