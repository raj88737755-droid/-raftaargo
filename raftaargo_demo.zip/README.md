
# RaftaarGo Demo (Flutter)

This is a lightweight prototype showing **Customer** and **Driver** flows:
- OTP-style login (mocked)
- Pickup/Drop selection (mocked)
- Vehicle selection
- Fare estimate
- Booking confirmation
- Driver accepts job

> Note: No real backend, maps, or payments. This lets you tap through the core UX now. You can build an APK locally in minutes.

## How to run
1. Install Flutter SDK: https://docs.flutter.dev/get-started/install
2. In a terminal:
   ```bash
   flutter create raftaargo_demo
   cd raftaargo_demo
   # Replace the generated files with the ones from this ZIP:
   # - overwrite pubspec.yaml
   # - overwrite the entire lib/ folder with this lib/
   flutter pub get
   flutter run  # to run on device/emulator
   ```

## Build APK (release)
```bash
flutter build apk --release
```
The built file will be at:
`build/app/outputs/flutter-apk/app-release.apk`

## What you'll see
- **Customer App** flow: Login → Pickup/Drop → Vehicle → Fare → Confirm
- **Driver App** flow: Login → Incoming Job → Accept → Navigate (mocked)

Switch between flows from the home screen toggle.
